#!/usr/bin/env python3
"""Reproducibly rebuild the v44-derived official-SDK candidate offline.

No organizer API, credentials or evaluation is accessed. The shipped SDK and
runtime pins are preserved. Source allowlist is the owner's submitted manifest.
"""
import hashlib
import importlib.util
import json
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SUBMISSION=ROOT/'submission'
NEW_FILES={'nova_agent/encounter_quality.py','nova_agent/korean_numbers.py'}

def main():
    baseline=json.loads((ROOT/'BASELINE_MANIFEST.json').read_text())
    allowed=set(baseline['files'])|NEW_FILES
    actual={str(p.relative_to(ROOT)) for package in ('nova_agent','competition')
            for p in (ROOT/package).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
    extra=actual-allowed
    if extra:raise SystemExit('Unapproved staging files: '+', '.join(sorted(extra)))
    missing=[n for n in allowed if not (ROOT/n).is_file()]
    if missing:raise SystemExit('Missing runtime files: '+', '.join(missing))
    audit_spec=importlib.util.spec_from_file_location('package_audit',ROOT/'scripts/audit_official_package.py')
    audit_module=importlib.util.module_from_spec(audit_spec);audit_spec.loader.exec_module(audit_module)
    for n in sorted(allowed):
        if audit_module.SECRET.search((ROOT/n).read_text(encoding='utf-8')):
            raise SystemExit('secret-shaped string in '+n)
    # Only package subfolders are refreshed; preserve unrelated output files.
    SUBMISSION.mkdir(exist_ok=True)
    for package in ('nova_agent','competition'):
        dest=SUBMISSION/package
        if dest.exists():shutil.rmtree(dest)
    for n in sorted(allowed):
        dest=SUBMISSION/n;dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(ROOT/n,dest)
    hashes={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in sorted(allowed)}
    manifest={'artifact_status':'LOCAL_V45_CANDIDATE','baseline':'owner-submitted nova-v44-submission.zip',
              'baseline_score':'63/100 (owner-reported)',
              'official_sdk_version':'1.0.1','runtime_contract':'documented SDK; local fake-SDK verified',
              'v45_official_score':'NOT_MEASURED','v45_live_model_status':'NOT_TESTED',
              'file_count':len(hashes),'files':hashes}
    (SUBMISSION/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    target=SUBMISSION/'submission.zip'
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for n in sorted(allowed|{'MANIFEST.json'}):
            info=zipfile.ZipInfo(n,(2026,10,13,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o100644 << 16
            archive.writestr(info,(SUBMISSION/n).read_bytes())
    report=audit_module.audit(target)
    if not report['all_pass']:raise SystemExit(json.dumps(report,ensure_ascii=False))
    # Clean directory import under isolation; no inherited PYTHONPATH or API.
    with tempfile.TemporaryDirectory(prefix='nova-v45-import-') as work:
        with zipfile.ZipFile(target) as archive:archive.extractall(work)
        code="import sys;sys.path.insert(0,sys.argv[1]);import run;from competition.nova_sdk_adapter import prepare;from nova_agent.encounter_quality import single_question;assert single_question('언제부터 불편했나요?');print('isolated import OK')"
        subprocess.run([sys.executable,'-I','-B','-c',code,work],check=True,cwd=work,timeout=30)
    print(json.dumps({'zip':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'files':len(hashes)+1,'zip_bytes':target.stat().st_size}))

if __name__=='__main__':main()
