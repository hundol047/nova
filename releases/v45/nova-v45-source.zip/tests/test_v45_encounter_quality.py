"""Independent boundary and complete-SDK regressions for the v44 changes.

All patients and Doctor responses are scripted fixtures, not official scoring.
No public case ID, hidden case, participant key or live API is accessed.
"""
import json
import pytest

from test_official_sdk_adapter import FakeServer, FakeClient, engine_config
from competition.nova_sdk_adapter import OfficialEncounter, Turn, _followup_understood
from nova_agent.state import PatientState
from nova_agent.clinical_interview import topic_known, next_history_clarification


@pytest.mark.parametrize('reply,known',[
    ('아테놀롤 25mg을 먹어요',True),('metformin 500mg twice daily',True),
    ('약 이름은 모르겠어요',False),('네',False),('혈압약 먹어요',False),
    ('먹는 약 없어요',True),
])
def test_medication_coverage_requires_a_name_or_explicit_denial(reply,known):
    s=PatientState(case_id='independent',chief_complaint='최근 쉽게 피곤해요')
    s.record_ask('medication','복용 중인 약 이름이 뭔가요?',reply)
    assert topic_known(s,'medication_name') is known


def test_allergy_drug_and_reaction_are_collected_separately():
    s=PatientState(case_id='allergy',chief_complaint='몸이 불편해요')
    s.record_ask('allergy','약물 알레르기가 있나요?','네')
    first=next_history_clarification(s)
    assert first and '약' in first[2] and '반응' not in first[2]
    s.record_ask(first[1],first[2],'페니실린이에요')
    second=next_history_clarification(s)
    assert second and '반응' in second[2]
    s.record_ask(second[1],second[2],'두드러기가 났어요')
    assert next_history_clarification(s) is None


@pytest.mark.parametrize('question,valid',[
    ('더위를 많이 타고 땀이 나나요?',False),
    ('가슴이 아프고 숨이 차나요?',False),
    ('병력과 증상을 모두 알려주세요',False),
    ('약 이름은요? 용량은요?',False),
    ('이전에도 같은 증상이 있었나요?',True),
    ('잠들기와 잠 유지 중 무엇이 어렵나요?',True),
    ('배변 횟수가 늘었나요?',True),
])
def test_patient_receives_one_question_attribute(question,valid):
    from nova_agent.encounter_quality import single_question
    assert single_question(question) is valid


@pytest.mark.parametrize('expected,reply,understood',[
    ('2~3일 내 재진하세요','모레 가겠습니다',True),
    ('2~3일 내 재진하세요','한 달 뒤에 갈게요',False),
    ('1~2주 내 재진하세요','7일 뒤에요',True),
    ('1~2주 내 재진하세요','네',False),
    ('3~6개월 후 키를 확인해요','3개월 뒤요',True),
])
def test_teachback_understands_days_and_equivalent_intervals(expected,reply,understood):
    assert _followup_understood(reply,expected) is understood


def test_spoken_measurements_are_parsed_without_altering_raw_answers():
    from nova_agent.clinical_profiles import growth_velocity
    from nova_agent.korean_numbers import normalize_spoken_numbers
    from competition.nova_sdk_adapter import _history_line
    assert growth_velocity('1년 전 키 백이십 센티미터, 현재 키 백이십육 센티미터')==6
    assert normalize_spoken_numbers('십육 점 오 키로그람')=='16.5 kg'
    assert normalize_spoken_numbers('두세 알')=='두세 알'
    t=Turn('SAY','체중이 몇 kg 줄었나요?','칠 킬로 빠졌어요','associated_symptoms:weight_change',4)
    line=_history_line(t)
    assert t.reply in line and '7 kg' in line and '턴 4' in line


def test_generic_test_reason_keeps_supported_alternative_workup():
    from nova_agent.encounter_quality import specific_test_plan
    entry={'id':'pneumonia','discriminating_tests':['cxr','cbc']}
    plan={'tests':'심전도, 트로포닌','follow_up':'','spoken_follow_up':'','spoken_precautions':''}
    result=specific_test_plan(plan,entry)
    assert '심전도' in result['tests'] and '트로포닌' in result['tests']
    assert '폐렴' in result['tests'] and '미시행' in result['tests']
    assert '48~72시간' in result['follow_up']


def test_pe_testing_is_conditional_and_normal_early_troponin_is_not_exclusion():
    from nova_agent.encounter_quality import specific_test_plan
    for cid,tests,words in [
        ('pulmonary_embolism',['d_dimer','ct_chest_angio'],'사전확률'),
        ('acute_coronary_syndrome',['ecg','troponin'],'반복 평가'),
    ]:
        result=specific_test_plan({'tests':'','follow_up':''},{'id':cid,'discriminating_tests':tests},urgent=True)
        assert words in result['tests'] and '즉시' in result['follow_up']


def test_model_test_plan_requires_real_indication_and_known_workup():
    from nova_agent.encounter_quality import merged_model_tests
    rows=[{'test':'ECG','indication':'두근거림의 리듬 원인 구분','evidence':'가슴이 두근거려요'},
          {'test':'MRI','indication':'두통 확인','evidence':'두통이 있어요'},
          {'test':'TSH','indication':'다른 원인 확인','evidence':'환자가 말하지 않은 열'}]
    plan=merged_model_tests({'tests':'기본 계획'},{'test_plan':rows},'가슴이 두근거려요',{'ECG','TSH'})
    assert 'ECG' in plan['tests'] and 'MRI' not in plan['tests'] and 'TSH' not in plan['tests']


class AdaptiveServer(FakeServer):
    def __init__(self,exam='특이 소견(-)'):
        super().__init__();self.plan_positions=[];self.exam_reply=exam;self.plan_calls=0

    def session(self):
        row=super().session()
        row['initial']={'opening':'41세 여자입니다. 간헐적으로 어지러워서 왔어요.',
                        'vital_signs':'BP 118/74, HR 80, RR 16, Temp 36.7, SpO2 98%'}
        return row

    def chat(self,body):
        self.chat_calls+=1
        system=body['messages'][0]['content']
        if '"questions"' in system:
            self.plan_positions.append(self.turns);self.plan_calls+=1
            if self.plan_calls==1:
                value={'questions':[{'text':'가슴이 아프고 숨이 차나요?'},
                                    {'text':'한 번 증상이 생기면 얼마나 지속되나요?','category':'duration'}],
                       'exams':['폐를 청진하겠습니다']}
            else:
                value={'questions':[{'text':'증상이 얼마나 자주 생기나요?','category':'timing'}], 'exams':[]}
        elif 'primary_diagnosis' in system:
            value={'primary_diagnosis':'Undifferentiated presentation','evidence':[]}
        else:
            return {'model':'openai/gpt-6-luna','choices':[{'message':{'content':'기립 시 어지러운가요?'}}],
                    'usage':{'prompt_tokens':100,'completion_tokens':20}}
        return {'model':'openai/gpt-6-luna','choices':[{'message':{'content':json.dumps(value,ensure_ascii=False)}}],
                'usage':{'prompt_tokens':150,'completion_tokens':60}}

    def action(self,body):
        result=super().action(body)
        if body['action']=='EXAM':
            result['result']=self.exam_reply
            self.events[-1]=(body['action'],body['content'],self.exam_reply)
        elif body['action']=='SAY':
            if '지속' in body['content']:result['content']='5분 정도 지속돼요'
            if '얼마나 자주' in body['content']:result['content']='하루 두 번 생겨요'
        return result


def test_full_sdk_reassesses_new_answers_and_filters_compound_questions():
    server=AdaptiveServer();e=OfficialEncounter(FakeClient(server),{},sleep=lambda _:None,log=lambda _:None)
    assert e.run()['status']=='completed'
    assert server.plan_positions and server.plan_positions[0]<=18
    assert server.plan_calls>=2
    assert not any('아프고 숨이' in t.text for t in e.turns)
    assert '5분 정도 지속돼요' in server.record['S']['hpi']
    assert server.record['O']['tests']=='' and server.turns<=48
    assert e.stats.calls<=16
    assert any(t.category=='understanding_check' for t in e.turns)


def test_new_exam_danger_stops_routine_followup_and_keeps_emergency_plan():
    server=AdaptiveServer(exam='SpO2 86%, RR 32')
    e=OfficialEncounter(FakeClient(server),{},sleep=lambda _:None,log=lambda _:None)
    assert e.run()['status']=='completed'
    assert '응급' in server.record['P']['disposition']
    first=next(i for i,t in enumerate(e.turns) if t.kind=='EXAM')
    assert not any(t.category=='patient_questions' for t in e.turns[first+1:])


def test_spoken_and_submitted_followup_share_one_owned_plan():
    from test_rubric_pipeline import supported_thyroid
    e=supported_thyroid();d,f=e._engine_final()
    e.final_consult={'primary_diagnosis':'Graves disease','evidence':['손이 떨려요'],
                    'plan':{'follow_up':'2년 뒤','tests':'폐렴 검사','treatment':'unsafe drug 400mg'}}
    e._accepted_primary=e._validated_primary(d,f);e._diagnosis_checked=True
    e._explain(d,f);note,_=e.official_record(d,f)
    assert '1~2주' in note['P']['follow_up']
    assert any('1~2주' in t.text for t in e.turns)
    assert '2년' not in note['P']['follow_up'] and '400mg' not in json.dumps(note)
    assert '폐렴 검사' not in note['P']['tests']


@pytest.mark.parametrize('unknown_result',[False,True])
def test_rejected_or_unknown_chronic_exam_is_not_repeated(unknown_result):
    from nova_agent.clinical_interview import next_clinical_action
    s=PatientState(case_id='rejected',chief_complaint='체중 감소; 식욕 증가; 더위를 못 견뎌요; 손이 떨려요')
    assert next_clinical_action(s)[1]=='thyroid_exam'
    if unknown_result:s.record_exam('thyroid_exam','결과는 잘 모르겠어요',request_text='갑상선을 촉진하겠습니다')
    else:s.record_exam_rejected('thyroid_exam',turn_used=True)
    action=next_clinical_action(s)
    assert action is None or action[1]!='thyroid_exam'


def test_mg_strength_does_not_answer_actual_tablet_count():
    s=PatientState(case_id='quantity',chief_complaint='수면제를 먹는데 잠이 안 와요')
    s.record_ask('medication','수면제 한 번 용량은 몇 mg인가요?','10mg이라고 적혀 있어요')
    assert not topic_known(s,'medication_tablets')
    s.record_ask('medication:medication_tablets','잠들기 전 수면제를 몇 알 드시나요?','4알 먹어요')
    assert topic_known(s,'medication_tablets')
    assert not topic_known(s,'medication_night_extra')
