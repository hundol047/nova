"""Missing Information Analyzer (spec section 6).

Given the current top differential, finds which not-yet-gathered piece of information (question /
exam / test) would do the most to separate the leading candidates from each other -- not "get more
info" in the abstract. Each candidate is scored on the axes spec section 6 lists; action_selector.py
turns those axis scores into the final utility ranking (section 7) using the configured weights.
"""

from __future__ import annotations

import math
from typing import Dict, Iterable, List, Literal, Optional

from pydantic import BaseModel

from nova_agent.differential import DifferentialItem
from nova_agent.knowledge.retrieval import disease_by_id
from nova_agent.safety import SafetyFinding, SafetyLayer
from nova_agent.state import PatientState
from nova_agent.taxonomy import EXAM_CATALOG, TEST_CATALOG, disease_specific_question

CandidateActionType = Literal["ASK", "EXAM", "TEST"]

# Expected-information-gain model (spec section 10): with no calibrated per-outcome likelihoods
# available, a real 2-outcome Bayesian update is approximated by pushing prior mass toward
# whichever side (affected / unaffected diseases) an outcome favors, rather than by using rank
# alone -- rank-weight accumulation (the previous implementation) only measures how highly-ranked
# the diseases touched by a candidate are, not how much a positive/negative result would actually
# change the picture. These constants set how strongly a hypothetical positive/negative result
# shifts the prior; they are not measured -- see this module's _expected_information_gain.
_POSITIVE_BOOST = 4.0
_NEGATIVE_BOOST = 1.0 / _POSITIVE_BOOST

_ANSWERED_CATEGORY_FIELD = {
    "onset": "symptom_onset", "duration": "duration", "severity": "severity",
}


class CandidateInfo(BaseModel):
    action_type: CandidateActionType
    key: str
    content_en: str
    content_ko: str
    content_ja: str = ""
    content_zh: str = ""
    disease_ids_discriminated: List[str]
    diagnostic_discrimination: float
    safety_relevance: float
    information_gain: float
    redundancy: float
    turn_cost: int
    top_competitor_separation: float = 0.0
    critical_resolution_gain: float = 0.0
    specificity_gain: float = 0.0
    decision_changing_value: float = 0.0


def _diagnosis_prior(differential: List[DifferentialItem]) -> Dict[str, float]:
    """A coarse internal prior over the current top-K differential, derived from each item's
    score_ratio (floored so no candidate diagnosis ever gets literally zero mass). This is used
    only to compute a relative expected-information-gain ranking between candidate actions --
    never surfaced to the user as a probability (spec section 4/9's calibration-band requirement
    is about user-facing confidence, not this internal scoring detail)."""
    if not differential:
        return {}
    raw = {d.diagnosis_id: max(d.score_ratio, 0.05) for d in differential}
    total = sum(raw.values()) or 1.0
    return {k: v / total for k, v in raw.items()}


def _entropy(probabilities: Iterable[float]) -> float:
    return -sum(p * math.log2(p) for p in probabilities if p > 0)


def _rescaled(prior: Dict[str, float], affected_ids: set, boost_affected: float) -> Dict[str, float]:
    updated = {k: p * (boost_affected if k in affected_ids else 1.0 / boost_affected) for k, p in prior.items()}
    total = sum(updated.values()) or 1.0
    return {k: v / total for k, v in updated.items()}


def _expected_information_gain(prior: Dict[str, float], affected_ids: set) -> float:
    """Expected reduction in differential entropy from a hypothetical positive/negative result on
    this candidate, using the coverage split (diseases this item discriminates for vs. not) as a
    proxy for the two outcomes -- the pairwise/coverage approximation spec section 10 explicitly
    allows when no calibrated per-outcome probability model exists."""
    if not prior or not affected_ids:
        return 0.0
    prior_entropy = _entropy(prior.values())
    p_affected = sum(prior.get(i, 0.0) for i in affected_ids)
    p_unaffected = max(0.0, 1.0 - p_affected)
    posterior_if_positive = _rescaled(prior, affected_ids, _POSITIVE_BOOST)
    posterior_if_negative = _rescaled(prior, affected_ids, _NEGATIVE_BOOST)
    expected_posterior_entropy = (
        p_affected * _entropy(posterior_if_positive.values())
        + p_unaffected * _entropy(posterior_if_negative.values())
    )
    return max(0.0, prior_entropy - expected_posterior_entropy)


MAX_TIER2_QUESTION_RANK = 6


def _resolve_entry(diagnosis_id: str) -> Optional[dict]:
    """Resolve a differential item's diagnosis_id to a KB-shaped dict, covering BOTH real Tier-1 KB
    diseases (disease_by_id) and ontology-sourced Tier-2/3 candidates (`onto::<concept_id>`, added
    to the pool by candidate_generator's ontology_broadening/ontology_retrieval steps).

    Before this fix, `disease_by_id()` alone returned None for every `onto::` id and analyze()
    silently `continue`d past it -- an ontology-sourced candidate could appear in the differential
    but never generate a single discriminating ASK/EXAM/TEST action of its own. Tier-2/3 entries now
    resolve to the SAME shallow, tier-aware dict `candidate_generator._concept_to_kb_entry()`
    already builds (Tier-2: bounded generic questions from real typical_features; Tier-3: correctly
    empty, no fabricated clinical content) -- reusing that logic rather than forking it."""
    entry = disease_by_id(diagnosis_id)
    if entry is not None:
        return entry
    if not diagnosis_id.startswith("onto::"):
        return None
    try:
        from nova_agent.candidate_generator import _concept_to_kb_entry
        from nova_agent.ontology.registry import get_default_catalog
    except Exception:
        return None
    concept_id = diagnosis_id[len("onto::"):]
    try:
        concept = get_default_catalog().get_condition(concept_id)
    except Exception:
        return None
    if concept is None:
        return None
    return _concept_to_kb_entry(concept)


def _already_answered(state: PatientState, category: str) -> bool:
    field = _ANSWERED_CATEGORY_FIELD.get(category)
    if field and getattr(state, field, None):
        return True
    if category == "past_medical_history" and state.past_medical_history:
        return True
    if category == "family_history" and state.family_history:
        return True
    if category == "social_history" and state.social_history:
        return True
    if category == "medication" and state.medications:
        return True
    if category == "allergy" and state.allergies:
        return True
    return False


class MissingInformationAnalyzer:
    def analyze(self, state: PatientState, differential: List[DifferentialItem],
                safety_findings: List[SafetyFinding]) -> List[CandidateInfo]:
        top_k = differential
        from nova_agent.config import get_config
        from nova_agent.resolution import is_resolved
        cfg = get_config()
        if cfg.competition_retrieval_enabled and cfg.focus_resolved_actions and differential:
            # Action focus only: safety/stop/ranking continue to see the full differential.
            # Never spend another discriminator on an addressed non-leading alternative.
            top_k = [d for i, d in enumerate(differential)
                     if i == 0 or not is_resolved(d.diagnosis_id, d.contradictory_evidence, state)]
        top_k_count = len(top_k) or 1
        safety = SafetyLayer()

        ask_candidates: dict[str, CandidateInfo] = {}
        exam_candidates: dict[str, CandidateInfo] = {}
        test_candidates: dict[str, CandidateInfo] = {}

        for item in top_k:
            entry = _resolve_entry(item.diagnosis_id)
            if entry is None:
                continue

            # A retrieval-only ontology candidate (no supporting evidence yet) must not spend turns on
            # its own generic feature questions: it is in the pool for RECALL, and the case's real
            # evidence has to earn it a place in the action budget first (Round M: enriched Tier-2
            # entries otherwise generated dozens of unrelated "associated_symptoms:<feature>" asks).
            if item.diagnosis_id.startswith("onto::") and (
                    not item.supporting_evidence or item.rank > MAX_TIER2_QUESTION_RANK):
                # ...and only while it is actually in contention (top ranks): every supported
                # long-tail candidate otherwise adds up to four generic questions to the action
                # pool, and since the encounter ends once no action has value left, a longer pool
                # meant longer encounters on cases that never involved those candidates.
                questions = []
            else:
                questions = entry.get("discriminating_questions", [])
            for discriminator in questions:
                category = discriminator.split(":", 1)[0]
                if cfg.competition_retrieval_enabled and ":" in discriminator:
                    # A feature-specific question cannot add the very same feature
                    # already supported for this hypothesis. Do not infer other
                    # answers, match substrings, or suppress generic safety history.
                    from nova_agent.ontology.normalizer import normalize
                    feature = normalize(discriminator.split(":", 1)[1])
                    if feature and feature in {normalize(s) for s in item.supporting_evidence}:
                        continue
                key = f"ask:{discriminator}"
                if state.question_asked(discriminator) or _already_answered(state, category):
                    continue
                spec = disease_specific_question(item.diagnosis_id, discriminator)
                cand = ask_candidates.setdefault(key, CandidateInfo(
                    action_type="ASK", key=discriminator, content_en=spec["text_en"], content_ko=spec["text_ko"],
                    content_ja=spec.get("text_ja", ""), content_zh=spec.get("text_zh", ""),
                    disease_ids_discriminated=[], diagnostic_discrimination=0.0, safety_relevance=0.0,
                    information_gain=0.0, redundancy=0.0, turn_cost=spec["turn_cost"],
                ))
                cand.disease_ids_discriminated.append(item.diagnosis_id)
                cand.safety_relevance = max(cand.safety_relevance, safety.safety_gain(item.diagnosis_id, safety_findings))

            for exam_id in entry.get("discriminating_exams", []):
                if state.exam_done(exam_id):
                    continue
                spec = EXAM_CATALOG.get(exam_id)
                if spec is None:
                    continue
                cand = exam_candidates.setdefault(exam_id, CandidateInfo(
                    action_type="EXAM", key=exam_id, content_en=spec["name_en"], content_ko=spec["name_ko"],
                    content_ja=spec.get("name_ja", ""), content_zh=spec.get("name_zh", ""),
                    disease_ids_discriminated=[], diagnostic_discrimination=0.0, safety_relevance=0.0,
                    information_gain=0.0, redundancy=0.0, turn_cost=spec["turn_cost"],
                ))
                cand.disease_ids_discriminated.append(item.diagnosis_id)
                cand.safety_relevance = max(cand.safety_relevance, safety.safety_gain(item.diagnosis_id, safety_findings))

            for test_id in entry.get("discriminating_tests", []):
                if state.test_done(test_id):
                    continue
                spec = TEST_CATALOG.get(test_id)
                if spec is None:
                    continue
                cand = test_candidates.setdefault(test_id, CandidateInfo(
                    action_type="TEST", key=test_id, content_en=spec["name_en"], content_ko=spec["name_ko"],
                    content_ja=spec.get("name_ja", ""), content_zh=spec.get("name_zh", ""),
                    disease_ids_discriminated=[], diagnostic_discrimination=0.0, safety_relevance=0.0,
                    information_gain=0.0, redundancy=0.0, turn_cost=spec["turn_cost"],
                ))
                cand.disease_ids_discriminated.append(item.diagnosis_id)
                cand.safety_relevance = max(cand.safety_relevance, safety.safety_gain(item.diagnosis_id, safety_findings))

        prior = _diagnosis_prior(top_k)
        all_candidates = list(ask_candidates.values()) + list(exam_candidates.values()) + list(test_candidates.values())
        for cand in all_candidates:
            affected_ids = set(cand.disease_ids_discriminated)
            n = len(affected_ids)
            # Peaks when the item splits the top-K roughly in half (maximally discriminative);
            # low when it's either irrelevant (n=0, filtered out already) or shared by every
            # candidate (doesn't separate anything, though it may still confirm/exclude the group).
            cand.diagnostic_discrimination = round((n * (top_k_count - n + 1)) / (top_k_count ** 2), 3) \
                if top_k_count else 0.0
            # Real expected information gain (spec section 10): entropy reduction over the
            # confidence-weighted differential, not how highly-ranked the touched diseases happen
            # to be (that was the previous, incorrect implementation).
            cand.information_gain = round(_expected_information_gain(prior, affected_ids), 3)
            if cfg.competition_retrieval_enabled:
                leaders = [d for d in top_k[:3] if d.supporting_evidence or d.rank == 1]
                pairs = [(a, b) for i, a in enumerate(leaders) for b in leaders[i+1:]]
                cand.top_competitor_separation = (
                    sum((a.diagnosis_id in affected_ids) != (b.diagnosis_id in affected_ids) for a,b in pairs)
                    / len(pairs) if pairs else 0.0)
                touched_leader = any(d.diagnosis_id in affected_ids for d in leaders)
                # Inverse metadata coverage is a transparent specificity proxy, not an outcome
                # likelihood. It prevents "relevant to everyone" from meaning "separates everyone".
                cand.specificity_gain = (1.0 / len(affected_ids) if affected_ids and touched_leader
                                         and cand.action_type in {"EXAM", "TEST"} else 0.0)
                unresolved = [d for d in top_k[:5] if d.diagnosis_id in affected_ids
                              and d.dangerous_if_missed and d.supporting_evidence
                              and not is_resolved(d.diagnosis_id, d.contradictory_evidence, state)]
                cand.critical_resolution_gain = max((1.0 / max(d.rank, 1) for d in unresolved), default=0.0)
                cand.decision_changing_value = max(cand.top_competitor_separation,
                                                  cand.critical_resolution_gain, cand.specificity_gain)
            cand.redundancy = 0.0  # already-performed items were excluded above, never generated here

        return all_candidates
