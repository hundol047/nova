"""Round Q: ONE final decision for the preliminary-round DIAGNOSE -- the submitted primary, the SOAP assessment, the
closing explanation and the metadata are all produced from it, so they can no longer disagree.

Completion and support are separate questions:
- ``completion_reason`` says WHY the encounter ends: the stop policy found the leader supported, nothing meaningful
  is left to ask or examine (information exhausted), or the interaction budget ran out. Running out of actions or
  turns permits completion; it never makes a diagnosis supported.
- ``support`` says whether a SPECIFIC named diagnosis may be the primary. A candidate selected by catalog or safety
  order with no evidence, a dangerous diagnosis resting on a single non-specific observation, a dangerous tie decided
  only by insertion order, or a profile whose required current context was never observed is not named. A better
  supported candidate further down the top five may be named instead; otherwise the completion is an explicit
  "undifferentiated presentation" (wire key ``unknown``). No candidate is deleted or marked absent: everything stays
  in the differential and the SOAP plan.

Danger is never a reason to name a diagnosis and never adds score. PROVENANCE: engineering-authored contract; the
four required-context profiles cite their clinical sources inline; not clinician-reviewed.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field, replace
from typing import Callable, Dict, List, Optional, Tuple

UNDIFFERENTIATED_ID = "unknown"
UNDIFFERENTIATED_LABEL = {"en": "Undifferentiated presentation", "ko": "미분화 증상 (진단 미확정)"}


@dataclass(frozen=True)
class FinalDecision:
    primary_id: str
    item: Optional[object]                 # the DifferentialItem named as primary, None when undifferentiated
    support: str                           # "SUPPORTED" | "UNDIFFERENTIATED"
    completion_reason: str                 # "supported" | "information_exhausted" | "budget"
    reasons: Tuple[str, ...] = field(default_factory=tuple)
    # Post-W calibration: other top-five candidates whose score is within CLOSE_ALTERNATIVE_RATIO of the named one.
    # Metadata only (no score, ranking or wire change): a named diagnosis with such a rival is PROVISIONAL.
    close_alternatives: Tuple[str, ...] = field(default_factory=tuple)

    @property
    def certainty(self) -> str:
        if self.undifferentiated:
            return "UNDIFFERENTIATED"
        return "PROVISIONAL" if self.close_alternatives else "LEADING"

    @property
    def undifferentiated(self) -> bool:
        return self.primary_id == UNDIFFERENTIATED_ID

    def label(self, lang: str = "en") -> str:
        if self.item is None:
            return UNDIFFERENTIATED_LABEL["ko" if lang == "ko" else "en"]
        return self.item.diagnosis

    def as_metadata(self) -> dict:
        return {"primary_id": self.primary_id, "support": self.support,
                "completion_reason": self.completion_reason, "reasons": list(self.reasons),
                "support_scope": "working_diagnosis_not_confirmation", "certainty": self.certainty,
                "close_alternatives": list(self.close_alternatives)}


def _current_texts(state) -> List[str]:
    return state.all_findings_text(include_context=False, include_family=False)


def _any_phrase(phrases: Tuple[str, ...]) -> Callable:
    def check(state, item) -> bool:
        from nova_agent.matching import feature_present_with_aliases
        current = _current_texts(state)
        return any(feature_present_with_aliases(p, current, scrub_negated_spans=True) for p in phrases)
    return check


_HEAT_EXPOSURE = re.compile(
    r"\b(?:in|from|during)\s+(?:the\s+)?(?:heat|sun)\b|\bheat\s?wave\b|\bhot (?:weather|day|car|room|sun)\b|"
    r"\bsauna\b|\bmarathon\b|\b(?:exercis|running|working|training)\w*\s+(?:\w+\s+){0,3}(?:in|under)\s+(?:the\s+)?"
    r"(?:heat|sun)\b|\b(?:3[5-9]|4[0-9])\s*(?:degrees|°c?)\s+(?:outside|today|out)\b|"
    r"폭염|더위|땡볕|뙤약볕|찜통|炎天下|猛暑|暑い中", re.I)


def _heat_exposure(state, item) -> bool:
    """Exposure wording in the patient's current statements, matched exactly (fuzzy matching let "very floppy, hot"
    satisfy "very hot day"). A body temperature is not exposure."""
    from nova_agent.evidence_scope import patient_evidence_text
    for text in _current_texts(state):
        scoped = patient_evidence_text(text)
        for m in _HEAT_EXPOSURE.finditer(scoped):
            clause = re.split(r"[.;!?]|,\s*but\b", scoped[:m.start()])[-1]
            if not re.search(r"\b(?:not|no|never|wasn't|weren't|didn't|hasn't|haven't)\b|않|안\s", clause, re.I):
                return True
    return False


def _hypertensive_range(state, item) -> bool:
    return any((v.sbp or 0) >= 180 or (v.dbp or 0) >= 120 for v in state.vital_signs)


# Required CURRENT context before a profile may be named as the primary (never a score change, never an exclusion).
_REQUIRED_CONTEXT: Dict[str, Tuple[str, Callable]] = {
    # Hypertensive emergency = severe BP elevation (>180/120 mm Hg) with acute target-organ damage
    # (Whelton PK et al., 2017 ACC/AHA High Blood Pressure Guideline, Hypertension 2018;71:e13, section 11.2).
    "hypertensive_emergency": ("measured blood pressure >= 180/120", _hypertensive_range),
    # Haemoptysis is, by definition, coughing up blood (NICE CKS "Haemoptysis", definition).
    "hemoptysis": ("blood actually coughed up", _any_phrase((
        "coughing up blood", "coughed up blood", "coughing blood", "blood in sputum", "blood in my sputum",
        "bloody sputum", "blood-stained sputum", "blood streaked sputum", "hemoptysis", "haemoptysis", "spitting blood",
        "객혈", "각혈", "피 섞인 가래", "피가 섞인 가래", "기침할 때 피"))),
    # SIADH is a cause of hypotonic hyponatraemia; symptoms alone cannot establish it -- a low sodium is required
    # (Spasovski G et al., European clinical practice guideline on hyponatraemia, Eur J Endocrinol 2014;170:G1).
    "siadh": ("documented low sodium", _any_phrase(("low sodium", "hyponatremia", "hyponatraemia", "저나트륨"))),
    # Ectopic pregnancy presents with pregnancy-related features: missed period, abdominal/pelvic pain, vaginal
    # bleeding, positive pregnancy test (NICE NG126, Ectopic pregnancy and miscarriage, section 1.2/1.3).
    # Round U follow-up: pain is the SHARED presenting symptom (torsion, appendicitis, ...), so it no longer
    # satisfies the PREGNANCY context by itself; a period/pregnancy/bleeding observation is required. Unchanged:
    # this never removes the candidate, lowers its score or changes the urgent plan.
    "ectopic_pregnancy": ("a pregnancy-related feature", _any_phrase((
        "missed period", "late period", "period is late", "positive pregnancy test", "pregnant", "vaginal bleeding",
        "생리가 늦", "생리를 안", "생리가 없", "임신", "질 출혈", "하혈"))),
    # Round W: heatstroke is defined by hyperthermia with CNS dysfunction AFTER environmental heat exposure (classic)
    # or strenuous exertion (exertional) (Epstein Y, Yanovich R. Heatstroke. N Engl J Med 2019;380:2449-2459). A
    # febrile, floppy, mottled infant without such exposure is not named heat stroke; the candidate, its score and
    # the urgent plan are unchanged.
    "heat_stroke": ("environmental heat exposure or exertion", _heat_exposure),
    # Round X: subarachnoid haemorrhage presents as an acute severe headache reaching maximum intensity within an hour
    # (NICE CG150 / NG228 2023 "Subarachnoid haemorrhage caused by a ruptured aneurysm" 1.1; Perry JJ et al., Ottawa
    # SAH rule, JAMA 2013;310:1248). Neck stiffness, photophobia and vomiting are shared with meningitis; without any
    # headache observation at all (a febrile toddler with meningism) SAH is not NAMED. The onset is often unrecorded,
    # so any reported headache satisfies this. The candidate, its score and the urgent plan are unchanged.
    "subarachnoid_hemorrhage": ("a reported headache", _any_phrase((
        "headache", "thunderclap headache", "worst headache of life", "sudden onset severe headache",
        "head hurts", "head is pounding", "두통", "머리가 아프", "머리가 깨질", "머리가 터질", "머리가 너무 아프"))),
}


def _profile_key(diagnosis_id: str) -> Optional[str]:
    for key in _REQUIRED_CONTEXT:
        if diagnosis_id == key or diagnosis_id.endswith(":" + key) or diagnosis_id.endswith("_" + key) \
                or (key in diagnosis_id and diagnosis_id.startswith("onto::")):
            return key
    return None


def _entry(diagnosis_id: str) -> dict:
    from nova_agent.differential import _entry_for_candidate_id
    return _entry_for_candidate_id(diagnosis_id) or {}


def _specific_support(item, entry: dict) -> List[str]:
    """Supporting items that are objective/confirmatory (not a symptom any condition could share)."""
    from nova_agent.clinical_concepts import is_objective_only_feature
    confirm = {str(c).lower() for c in entry.get("confirmatory_findings", [])}
    # Measured is not synonymous with disease-specific. A pulse threshold is
    # a real observation and safety concern, not the rhythm's cause/subtype.
    return [e for e in item.supporting_evidence if not _nonspecific_measurement(e)
            and (e.lower() in confirm or e.lower().startswith("elevated lactate") or is_objective_only_feature(e))]


def _nonspecific_measurement(phrase: str) -> bool:
    return phrase.lower() in {"pulse rate below 50", "pulse rate of 150 or more", "tachycardia", "bradycardia"}


def _hemodynamic_only(phrase: str) -> bool:
    """Rate/perfusion observations cannot identify an underlying cause alone.

    A broader gate treating *every* abnormal observation as interchangeable was
    rejected: it erased converging fever/mental-state and hypoxic presentations.
    Keep those distinctions; do not claim to have proved an etiology from vitals.
    """
    return _nonspecific_measurement(phrase) or phrase.lower() in {
        "hypotension", "tachypnea", "shock", "low blood pressure"}


def _distinct(evidence: List[str]) -> int:
    """Distinct supporting observations: the same canonical phrase counts once. (Several features stated in one
    sentence -- "crushing chest pain to my left arm with sweating" -- are several observations.)"""
    from nova_agent.ontology.normalizer import normalize
    return len({normalize(e) or e.lower() for e in evidence})


# Symptoms too common across presentations to name a cause on their own. Engineering-authored list.
_GENERIC_SYMPTOMS = frozenset({
    "dizziness", "dizzy", "lightheadedness", "lightheaded", "nausea", "vomiting", "fatigue", "tiredness", "weakness",
    "generalized weakness", "generalised weakness", "malaise", "headache", "confusion", "fever", "cough", "chest pain",
    "abdominal pain", "shortness of breath", "dyspnea", "breathlessness", "palpitations", "feeling unwell", "syncope",
    "altered mental status", "anxiety", "sweating", "diaphoresis", "back pain", "productive cough", "diarrhea",
})


def _base_name(name: str) -> str:
    return re.sub(r"\s*\(.*?\)", "", name or "").strip().lower()


def _generic_symptom(phrase: str) -> bool:
    # Grammatical qualifiers are not new discriminating evidence.
    plain = re.sub(r"^(?:(?:associated|reported|persistent|severe|marked|profound)\s+)+", "", phrase.strip().lower())
    # Round V: a shared symptom placed in a situational context ("chest pain after trauma") is still the shared
    # symptom -- a chest-wall injury and a pneumothorax share it. Only the context is removed, never a finding.
    plain = re.sub(r"\s+(?:after|following|since)\s+(?:a\s+)?(?:trauma|injury|a fall|fall|exercise|exertion)$", "", plain)
    if plain in _GENERIC_SYMPTOMS:
        return True
    # A conjunction stored as ONE catalog feature does not become specific merely
    # because its components were joined. Anatomical/trigger qualifiers and any
    # non-generic component keep their existing discriminating interpretation.
    parts = re.split(r"\s+(?:and|or|with)\s+", plain)
    return len(parts) > 1 and all(p in _GENERIC_SYMPTOMS for p in parts)


def _risk_context(phrase: str) -> bool:
    """Some shallow ontology profiles store risk context under typical_features.
    Preserve ranking inputs, but a past illness/age cannot establish a current illness."""
    return bool(re.search(r"^(?:(?:known |family )?history of |known .+ on |prior |previous |older age$|advanced age$|young age$)",
                          phrase.lower())) or phrase.lower() == "atrial fibrillation or vascular disease"


def _antecedent_context(phrase: str) -> bool:
    """Round V (NOVA_CONTEXT_V2): "recent viral illness", "recent cold", "recent trauma" describe what came BEFORE the
    current illness. Together with current findings such an antecedent discriminates (a viral prodrome before chest
    pain and palpitations); on its own it is not an observation of any current illness."""
    return get_config_flag("context_v2_enabled") and bool(re.search(r"^recent (?!onset\b)", phrase.lower()))


def get_config_flag(name: str) -> bool:
    from nova_agent.config import get_config
    return bool(getattr(get_config(), name, False))


def _positive_support(item) -> List[str]:
    from nova_agent.differential import _strip_negative_prefix
    entry = _entry(item.diagnosis_id)
    risk_only = {str(x).lower() for x in entry.get("risk_factors", [])}
    return [e for e in item.supporting_evidence if e.lower() not in risk_only and not _risk_context(e)
            and _strip_negative_prefix(e) is None and e != "documented diagnosis"]


def discriminated_by_answers(item, state, differential: list) -> bool:
    """Round U follow-up: may ONE generic observation support a NON-dangerous working diagnosis?

    Only after the encounter has actually discriminated it: the patient gave explicit (not unknown / declined)
    answers to targeted questions, every other candidate that shares the observation has been contradicted by
    those answers, no other candidate scores as high, and no dangerous candidate has any positive (non-risk)
    support. A dangerous diagnosis is never named this way, and nothing here changes a score. A bare "No" is taken
    at face value: the runtime cannot tell a real denial from a simulator default (reported separately)."""
    if item.dangerous_if_missed or "documented diagnosis" in item.supporting_evidence:
        return False
    asks = [o for o in getattr(state, "action_outcomes", []) if o.action_type == "ASK"]
    observed = [o for o in asks if o.status == "OBSERVED"]
    targeted = [o for o in observed if o.targets and o.faithful]
    unknown = [o for o in asks if o.status == "UNKNOWN"]
    if not targeted or len(unknown) >= len(observed) or not state.pertinent_negatives:
        return False
    shared = {e.lower() for e in _positive_support(item)}
    for other in differential:
        if other.diagnosis_id == item.diagnosis_id or getattr(other, "fallback_candidate", False):
            continue
        if other.score > 0 and other.score >= item.score - 1e-6:
            return False
        if other.dangerous_if_missed and _positive_support(other):
            return False
        if shared & {e.lower() for e in other.supporting_evidence} and not other.contradictory_evidence:
            return False
    return True


def support_problems(item, state, differential: list) -> List[str]:
    """Why ``item`` may not be NAMED as the primary (empty list: it may)."""
    from nova_agent.differential import _strip_negative_prefix
    entry = _entry(item.diagnosis_id)
    problems: List[str] = []
    if entry.get('support_requirements'):
        from nova_agent.clinical_profiles import profile_problems
        problems.extend(profile_problems(entry, state, item.supporting_evidence))
    risk_only = {str(x).lower() for x in entry.get("risk_factors", [])}
    risk_only.update(e.lower() for e in item.supporting_evidence if _risk_context(e))
    positive = [e for e in item.supporting_evidence
                if e.lower() not in risk_only and _strip_negative_prefix(e) is None and e != "documented diagnosis"]
    documented = "documented diagnosis" in item.supporting_evidence
    if getattr(item, "fallback_candidate", False) or item.score <= 0 or not (positive or documented):
        return ["no_positive_support"]
    if not documented and all(_antecedent_context(e) for e in positive):
        return ["antecedent_context_only"]
    specific = _specific_support(item, entry)
    observations = [e for e in item.supporting_evidence if _strip_negative_prefix(e) is None]
    if positive and all(_hemodynamic_only(e) for e in positive) and not documented:
        problems.append("only_hemodynamic_support")
    if (not specific and not documented and _distinct(observations) <= 1
            and all(e.lower() in risk_only or _generic_symptom(e) or _nonspecific_measurement(e) for e in observations)):
        # ONE observation in total, and it is a symptom shared by most presentations or a lone risk factor
        # ("dizziness" -> ectopic pregnancy). A single SPECIFIC sign (facial droop) is not caught here.
        if not discriminated_by_answers(item, state, differential):
            problems.append("single_nonspecific_support")
    index = next((i for i, d in enumerate(differential) if d.diagnosis_id == item.diagnosis_id), None)
    generic_only = all(e.lower() in risk_only or _generic_symptom(e) or _nonspecific_measurement(e) for e in observations)
    if item.dangerous_if_missed and generic_only and not specific and not documented:
        problems.append("only_nonspecific_support")
    if index is not None and item.dangerous_if_missed and not specific and not documented and generic_only:
        # A tie on generic evidence alone would be decided by insertion order. A neighbour that is the same disease
        # under another catalog name ("Septic Arthritis" / "Septic Arthritis (Joint)") is not a competitor.
        neighbours = [differential[j] for j in (index - 1, index + 1) if 0 <= j < len(differential)]
        if any(abs(n.score - item.score) < 1e-6 and _base_name(n.diagnosis) != _base_name(item.diagnosis)
               for n in neighbours):
            problems.append("tied_on_nonspecific_support")
    profile = _profile_key(item.diagnosis_id)
    if profile is not None:
        description, check = _REQUIRED_CONTEXT[profile]
        if not check(state, item):
            problems.append(f"required_context_missing:{description}")
    # ESC 2022 ventricular-arrhythmia guideline, doi:10.1093/eurheartj/ehac262,
    # section 5.1.3: rhythm subtype requires recorded electrical evidence. A rate alone
    # does not identify ventricular origin. Current clinician documentation is separate.
    if item.diagnosis_id == "onto::tier2:ventricular_tachycardia" and not documented:
        from nova_agent.matching import feature_present_with_aliases
        if not feature_present_with_aliases("ventricular tachycardia", state.objective_findings_text(),
                                            scrub_negated_spans=True, strict=True):
            problems.append("rhythm_subtype_not_observed")
    # NICE CG109 1.1.4.3: uncomplicated faint requires no features suggesting an
    # alternative. Reuse the existing measured-rate thresholds; do not infer an ECG.
    if item.diagnosis_id in {"vasovagal_syncope", "orthostatic_hypotension", "onto::tier2:orthostatic_hypotension"}:
        rate = state.latest_vital_signs()
        from nova_agent.vitals_parser import fast_pulse_threshold
        if rate and rate.heart_rate is not None and (
                rate.heart_rate < 50 or rate.heart_rate >= fast_pulse_threshold(state.demographics.age)):
            problems.append("marked_pulse_rate_requires_explanation")
    return problems


HIERARCHY_NEAR_TIE = 0.9


def _curated_syndrome_on_same_observations(leader, state, differential):
    """Round V (NOVA_HIERARCHY_V2): naming a specific cause over a broader syndrome needs an observation the
    syndrome does not already explain.

    When an unreviewed Tier-2 leader has none of its own confirmatory findings observed, and a curated Tier-1
    candidate of the SAME category in the top three scores within 10% of it and is supported by at least two of the SAME observations
    (each Tier-1 phrase is present in the leader's support), the curated profile is named: a perforated viscus whose
    free air cannot be imaged rests on the same rigidity and rebound as the acute abdomen. Nothing changes a score,
    excludes a candidate or uses danger; the Tier-2 cause stays in the differential."""
    from nova_agent.matching import feature_present_with_aliases
    if not get_config_flag("hierarchy_v2_enabled") or not leader.diagnosis_id.startswith("onto::tier2:"):
        return None
    if leader.score <= 0:
        return None
    entry = _entry(leader.diagnosis_id)
    objective = state.objective_findings_text()
    if any(feature_present_with_aliases(c, objective, scrub_negated_spans=True)
           for c in entry.get("confirmatory_findings", [])):
        return None
    observed = _positive_support(leader)
    for other in differential[1:3]:
        if other.diagnosis_id.startswith("onto::") or other.score < HIERARCHY_NEAR_TIE * leader.score:
            continue
        # Round W: a broader syndrome of a cause belongs to the same organ-system category (acute abdomen /
        # perforated viscus); pneumonia is not a broader form of heart failure although both explain crackles.
        if not entry.get("category") or _entry(other.diagnosis_id).get("category") != entry.get("category"):
            continue
        shared = [p for p in _positive_support(other) if feature_present_with_aliases(p, observed, scrub_negated_spans=False)]
        if len(shared) >= 2 and not support_problems(other, state, differential):
            return other
    return None


CLOSE_ALTERNATIVE_RATIO = 0.9


def _with_certainty(decision: FinalDecision, differential: list) -> FinalDecision:
    """Attach the near-tied rivals of the named diagnosis (calibration metadata; the decision itself is unchanged)."""
    from nova_agent.config import get_config
    item = decision.item
    if item is None or not get_config().decision_certainty or item.score <= 0:
        return decision
    rivals = tuple(d.diagnosis_id for d in differential[:5]
                   if d.diagnosis_id != item.diagnosis_id and d.score >= CLOSE_ALTERNATIVE_RATIO * item.score
                   and d.supporting_evidence)
    return replace(decision, close_alternatives=rivals) if rivals else decision


def decide_final(state, differential: list, completion_reason: str = "supported") -> FinalDecision:
    return _with_certainty(_decide_final(state, differential, completion_reason), differential)


def _decide_final(state, differential: list, completion_reason: str = "supported") -> FinalDecision:
    """The leader if it may be named; else the best-ranked top-five candidate with SPECIFIC or at least two distinct
    supporting observations that may be named; else an undifferentiated completion."""
    from nova_agent.config import get_config
    if not differential:
        return FinalDecision(UNDIFFERENTIATED_ID, None, "UNDIFFERENTIATED", completion_reason, ("empty_differential",))
    leader = differential[0]
    if not get_config().final_decision_enabled:
        return FinalDecision(leader.diagnosis_id, leader, "SUPPORTED", completion_reason, ("final_decision_off",))
    leader_problems = support_problems(leader, state, differential)
    if not leader_problems:
        broader = _curated_syndrome_on_same_observations(leader, state, differential)
        if broader is not None:
            return FinalDecision(broader.diagnosis_id, broader, "SUPPORTED", completion_reason,
                                 (f"leader:specific_cause_without_discriminating_observation:{leader.diagnosis_id}",
                                  f"named:{broader.diagnosis_id}"))
        return FinalDecision(leader.diagnosis_id, leader, "SUPPORTED", completion_reason)
    reasons = tuple(f"leader:{p}" for p in leader_problems)
    for alt in differential[1:5]:
        if support_problems(alt, state, differential):
            continue
        entry = _entry(alt.diagnosis_id)
        # Round U follow-up: replacing the ranked leader needs more than two symptoms that most presentations share
        # ("nausea" + "vomiting" do not name pancreatitis over a blocked leader). At least one supporting
        # observation must be non-generic; two generic ones are not two independent specific findings.
        nongeneric = [e for e in _positive_support(alt) if not _generic_symptom(e) and not _nonspecific_measurement(e)]
        if ("documented diagnosis" in alt.supporting_evidence or _specific_support(alt, entry)
                or (nongeneric and _distinct(alt.supporting_evidence) >= 2)):
            return FinalDecision(alt.diagnosis_id, alt, "SUPPORTED", completion_reason,
                                 reasons + (f"named:{alt.diagnosis_id}",))
    return FinalDecision(UNDIFFERENTIATED_ID, None, "UNDIFFERENTIATED", completion_reason, reasons)
